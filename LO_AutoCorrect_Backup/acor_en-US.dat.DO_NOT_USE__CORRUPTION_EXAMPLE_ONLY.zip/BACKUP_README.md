My guess/assumption:

Folder names with typos are the result of nondeterministic conflicts that AutoCorrect can't figure out how to deal with.
* Put another way, one input word gets mapped to *multiple* output words.
* E.g., `trasnfrom` -> {`transform`, ``}. Is LO supposed to convert `trasnfrom` to `transform`, or is LO supposed to convert `trasnfrom` to the empty string ``?

What SHOULD happen (in normal circumstances) is: One input word gets mapped to (a maximum of) One output word. This way, there's no ambiguity when performing a substitution - there's only one option/choice to pick from.
* E.g., `trasnfrom` -> `transform`

My guess is that whenever LibreOffice somehow comes across an AutoCorrect entry that maps one input word to multiple output words, it creates a folder that contains any/all possibly-required context of one of the "corrected" words, where the folder's name is the typo and the inner file(s) detail what that typo's "corrected" word should be.